
package pk.edu.nust.seecs.springlogaspects.view;

import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import pk.edu.nust.seecs.springlogaspects.bo.AddressBo;
import pk.edu.nust.seecs.springlogaspects.bo.AddressBoImpl;
import pk.edu.nust.seecs.springlogaspects.bo.StructureBo;
import pk.edu.nust.seecs.springlogaspects.bo.StructureBoImpl;


public class Executioner extends JFrame implements Runnable {
    
    public static void main(String[] args) {
        Executioner admin = new Executioner();
        Thread t = new Thread(admin);
        t.start();
    }

    public Executioner(){
        
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext.xml");
        
        AddressBo addressManager = applicationContext.getBean("addressManager",AddressBo.class);
        
        //Executioner admin = new Executioner();2
        Integer AddressId1 = addressManager.addNewAddress("Dubai", "Dubai", "UAE");
          
        //New Structure Id Array
        ArrayList<Integer> structureIds = new ArrayList<>();
        
        //StructureBo structureManager = admin.getStructureManager();
        StructureBo structureManager = applicationContext.getBean("structureManager",StructureBo.class);
        structureIds.add(structureManager.addStructures("Burj Khalifa", AddressId1));
        
        Integer AddressId2 = addressManager.addNewAddress("Toronto", "Ontario", "Canada");
        structureIds.add(structureManager.addStructures("Willis Tower", AddressId2));
        
        Integer AddressId3 = addressManager.addNewAddress("NYC", "New York", "USA");
        structureIds.add(structureManager.addStructures("World Trade Center", AddressId3));
        
        Iterator<Integer> structureIterator = structureIds.iterator();
        JTextArea outputText= new JTextArea();
        
        while(structureIterator.hasNext()){
            Integer structureWithId = structureIterator.next();
            outputText.append("Now Printing structure with id:"+structureWithId);
            
            structureManager.sayHello(structureWithId);
            //structureManager.getInfo();
            structureManager.printAddress(outputText);
        }
        this.add(outputText);
        this.pack();
        
    }

    @Override
    public void run() {
        this.setVisible(true);
    }
}
