/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pk.edu.nust.seecs.springlogaspects.bo;

/**
 *
 * @author Syeda Fareed
 */

//Business objects are used to separate your business logic from code to provide loose coupling
public interface AddressBo {
        public Integer addNewAddress(String city, String state, String country) ;
    
}

