
package pk.edu.nust.seecs.springlogaspects.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import pk.edu.nust.seecs.springlogaspects.bo.AddressBo;
import pk.edu.nust.seecs.springlogaspects.bo.AddressBoImpl;
import pk.edu.nust.seecs.springlogaspects.bo.StructureBo;
import pk.edu.nust.seecs.springlogaspects.bo.StructureBoImpl;

@Configuration
@ComponentScan(basePackages={"pk.edu.nust.seecs.springlogaspects"})

//These Beans have been defined using the annotated configuration classes. 
//So we don't need to define them in application context

public class SupplimentaryAnnotatedConfig {

    @Bean
    public AddressBo addressManager() {
        return new AddressBoImpl();
    }
    
    @Bean
    public StructureBo structureManager() {
        return new StructureBoImpl();
    }
    
}
