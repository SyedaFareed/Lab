/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pk.edu.nust.seecs.springlogaspects.dao;


import java.util.ArrayList;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import pk.edu.nust.seecs.springlogaspects.entity.Address;
import pk.edu.nust.seecs.springlogaspects.entity.Structure;
import pk.edu.nust.seecs.springlogaspects.util.HibernateUtil;

/**
 *
 * @author Syeda Fareed
 */

/*Data access object (DAO) are used to communicate with database. It acts as a bridge between database and Business Object(BO)
StrucutreDao contains methods that are called in busines object (StructureBoImpl). StrucutreBoImpl sends data as arguments that is 
commited in database by DAO.

*/

public class StructureDao {
    @Autowired
    AddressDao addressPersistor;
    
    private SessionFactory sessionFactory;
 
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    
    public void addAddress(Structure structure,Integer addressId) {
        Transaction trns = null;
        Session session = this.sessionFactory.openSession();
        try {
            trns = session.beginTransaction();
            structure.setAddress(addressPersistor.getAddressById(addressId));
            //structure.addAddress(addressPersistor.getAddressById(addressId));
            session.saveOrUpdate(structure);
            session.getTransaction().commit();
        } catch (RuntimeException e) {
            if (trns != null) {
                trns.rollback();
            }
            e.printStackTrace();
        } finally {
            session.flush();
            session.close();
        }
    }
    
    public void addStructure(Structure structure) {
        Transaction trns = null;
        Session session = this.sessionFactory.openSession();
        try {
            trns = session.beginTransaction();
            session.save(structure);
            session.getTransaction().commit();
        } catch (RuntimeException e) {
            if (trns != null) {
                trns.rollback();
            }
            e.printStackTrace();
        } finally {
            session.flush();
            session.close();
        }
    }

    public void deleteStructure(int structureid) {
        Transaction trns = null;
        Session session = this.sessionFactory.openSession();
        try {
            trns = session.beginTransaction();
            Structure structure = (Structure) session.load(Structure.class, new Integer(structureid));
            session.delete(structure);
            session.getTransaction().commit();
        } catch (RuntimeException e) {
            if (trns != null) {
                trns.rollback();
            }
            e.printStackTrace();
        } finally {
            session.flush();
            session.close();
        }
    }

    public void updateStructure(Structure structure) {
        Transaction trns = null;
        Session session = this.sessionFactory.openSession();
        try {
            trns = session.beginTransaction();
            session.update(structure);
            session.getTransaction().commit();
        } catch (RuntimeException e) {
            if (trns != null) {
                trns.rollback();
            }
            e.printStackTrace();
        } finally {
            session.flush();
            session.close();
        }
    }

    public List<Structure> getAllStructures() {
        List<Structure> structures = new ArrayList<Structure>();
        Transaction trns = null;
        Session session = this.sessionFactory.openSession();
        try {
            trns = session.beginTransaction();
            structures = session.createQuery("from Structure").list();
        } catch (RuntimeException e) {
            e.printStackTrace();
        } finally {
            session.flush();
            session.close();
        }
        return structures;
    }

    public Structure getStructureById(int structureid) {
        Structure structure = null;
        Transaction trns = null;
        Session session = this.sessionFactory.openSession();
        try {
            trns = session.beginTransaction();
            String queryString = "from Structure where id = :id";
            Query query = session.createQuery(queryString);
            query.setInteger("id", structureid);
            structure = (Structure) query.uniqueResult();
        } catch (RuntimeException e) {
            e.printStackTrace();
        } finally {
            session.flush();
            session.close();
        }
        return structure;
    }
}
