/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pk.edu.nust.seecs.springlogaspects.bo;

import java.util.ArrayList;
import javax.swing.JTextArea;

/**
 *
 * @author Syeda Fareed
 */

//Business objects are used to separate your business logic from code to provide loose coupling

public interface StructureBo {
    
    public void sayHello(Integer studentId);

    public String getInfo();

    public void printAddress(JTextArea outputText);
    
    public Integer addStructures(String structureName, Integer addressId);
    
}
