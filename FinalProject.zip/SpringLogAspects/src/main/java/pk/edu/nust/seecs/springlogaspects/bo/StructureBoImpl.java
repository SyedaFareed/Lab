/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pk.edu.nust.seecs.springlogaspects.bo;

import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.JTextArea;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.Set;
import javax.swing.JOptionPane;
import pk.edu.nust.seecs.springlogaspects.dao.StructureDao;
import pk.edu.nust.seecs.springlogaspects.entity.Address;
import pk.edu.nust.seecs.springlogaspects.entity.Structure;

/**
 *
 * @author Syeda Fareed
 */

//Business objects are used to separate your business logic from code to provide loose coupling. StructureBoImpl 

public class StructureBoImpl implements StructureBo {

    @Autowired
    StructureDao structurePersistor;
    
    Structure structureActor;
    
    @Override
    public void sayHello(Integer structureId) {
        structureActor = structurePersistor.getStructureById(structureId);
    }

    @Override
    public String getInfo() {
        return structureActor.toString();
    }

    @Override
    public void printAddress(JTextArea outputText) {
        
        outputText.append("Structure ID:"+structureActor.getStructureId()+"\r\n");
        outputText.append("Structure Courses:"+structureActor.getAddress()+"\r\n");  
        outputText.append(structureActor.toString()+"\r\n");
        }
        
    @Override
    public Integer addStructures(String structureName, Integer addressId) {
        
        Structure newStructure = new Structure();
        newStructure.setName(structureName);
        structurePersistor.addStructure(newStructure);
        
        structurePersistor.addAddress(newStructure, addressId);
        
       
//        Iterator<Integer> structureCourseIterator = structureCourses.iterator();
//        while(structureCourseIterator.hasNext()){
//            structurePersistor.addCourse(newStudent, structureCourseIterator.next());
        
        return newStructure.getStructureId();
    }
    
    
    }
    
    

    
