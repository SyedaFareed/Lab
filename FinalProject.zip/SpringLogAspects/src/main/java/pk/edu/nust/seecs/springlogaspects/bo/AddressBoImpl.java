/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pk.edu.nust.seecs.springlogaspects.bo;

import org.springframework.beans.factory.annotation.Autowired;

import pk.edu.nust.seecs.springlogaspects.entity.Address;
import pk.edu.nust.seecs.springlogaspects.dao.AddressDao;

/**
 *
 * @author Syeda Fareed
 */

//Business objects are used to separate your business logic from code to provide loose coupling

public class AddressBoImpl implements AddressBo{
    @Autowired
    AddressDao addressPersistor;

    @Override
    public Integer addNewAddress(String city, String state, String country) {
        Address newAddress = new Address();
        newAddress.setCity(city);
        newAddress.setState(state);
        newAddress.setCountry(country);
        
        addressPersistor.addAddress(newAddress);
        return newAddress.getAddressId();
    }
   
}
    
 
